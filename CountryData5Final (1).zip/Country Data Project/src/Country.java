//Code for Tului Battulga
import java.util.ArrayList;

public class Country {
	//instance variables go here
	private String countryName;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> data;
	//constructor
	public Country(String countryName, String series, ArrayList<Integer> years, ArrayList<Double> data) {
		this.countryName = countryName;
		this.series = series;
		this.years = years;
		this.data = data;
	}
	//prints all the information about a country in proper format
	public String toString() {
		String combined = "";
		for (int i = 0; i < years.size(); i++) {
			combined += years.get(i)+" ";
		}
		String values = "";
		double min = Math.round(min());
		double max = Math.round(max());
		for (int i = 0; i < data.size(); i++) {
			values += data.get(i)+" ";
		}
		combined += "\n" + values + "\n";
		combined += "This is the \"" + series + "\" for " + countryName + "\n";
		combined += "Minimum: " + min + "\n" + "Maximum: " + max;
		combined += "\nTrending: " + getTrend();
		return combined;
	}
	
	//This method returns the lowest value (unrounded) in the data stored for the country.
	public double min() {
		double min = 1000000000;
		for (double value : data) {
			if (value < min) min = value;
		}
		return min;
			}
	//This method returns the highest value (unrounded) in the data stored for the country.
	public double max() {
		double max=-1000000000;
		for (double value : data) {
			if (value > max) max = value;
		}
		return max;
			}
	
	// This method returns the units for the stored data.  The string that is returned should not include parentheses.
	public String getUnits() {
		if (series.indexOf("(") == -1) //If there's no units 
			return "";
		String unit = series.substring(series.indexOf("(") + 1, series.indexOf(")")); // if there are units returns everything between the paranthesis using substring
		return unit;
	}
	
	//This method returns an acronym made of the first letter in each of the words in the series name, but excludes: of, in, the, at, to, by, per, on, a, an.  The acronym should be in ALL CAPS and should not include the units.  In the example above, a call to getAcronym would shorten the data series name Access to electricity to simply return: AE.  (If you're using something like GDP that is already an acronym, it might help for testing to adjust your data file to read �Gross domestic product�.) 
	public String getAcronym() {
		String acronym = "";
		String[] not = {"of", "in", "the", "at", "to", "by", "per", "on", "a", "an"};
		String[] words = this.getSeries().split(" ");
		for (int i = 0; i < words.length; i++) {
			boolean contains = false;
			for (int j = 0; j < not.length; j++) {
				if (words[i].equals(not[j])) {
					contains = true;
				}
			}
			if (contains==false) {
				acronym += words[i].charAt(0);
			}
		}
		return acronym.toUpperCase();
	}
	
	
	//This method returns  up, down, or no trend depending on which direction the data is trending.  This method must call the private methods trendsUp and trendsDown.
	public String getTrend() {
		if (trendsUp()==true) 
			return "up";
		if (trendsDown()==true) 
			return "down";
		else 
		return "no trend";
	}
	
	//This method returns a boolean representing whether each successive data point is higher than the previous one.  For example, the method would return true if the data values were:  20, 22, 25, 27, 33.  The method would return false if the data values were:  20, 22, 22, 22, 25, 33.  (Yes, this is a gross simplification of something that would be better done with regression, but I don�t think anyone is up for programming that right now.  Wait� are you?)   ;)
	private boolean trendsUp() {
		for (int i = 1; i < data.size(); i++) {
			if (data.get(i) <= data.get(i-1)) 
				return false;
		}
		return true;
	}
	
	//Same idea as trendsUp each data point must be lower than the one that came before, otherwise it will return false.
	private boolean trendsDown() {
		for (int i = 1; i < data.size(); i++) {
			if (data.get(i) >= data.get(i-1)) 
				return false;
		}
		return true;
	}
	//sets the data for a country
	public void setData(ArrayList<Double> data) {
		this.data = data;
	}
	//gets the data for a country and returns to user
	public ArrayList<Double> getData() {
		return data;
	}
	//sets the series for a country
	public void setSeries(String series) {
		this.series = series;
	}
	//gets the series for a country and returns to user
	public String getSeries() {
		if (series.indexOf("(") == -1) 
			return series;
		else {
			String[] series1=series.split("[(]");
			return series1[0];
		}
	//gets the country name and returns to user
	}
	public String getCountry() {
		return countryName;
	}
	//gets the years and returns to user
	public ArrayList<Integer> getYears() {
		return years;
	}
	//takes the data input into the method and adds it to the country
	public void addDataPoint(int year, double newDatum) {
		years.add(year);
		data.add(newDatum);
	}
	//takes the data input into the method and edits the data of the given year
	public void editDataPoint(int year, double newDatum) {
		data.set(years.indexOf(year), newDatum);
	}

}
