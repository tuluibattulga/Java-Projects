//Code for Tului Battulga 1st Period
import java.io.*;
import java.util.*;
public class CountryClient {
	public static void main(String[] args) throws FileNotFoundException {
		File inputFile = new File("countryDataSet.csv");
		Scanner input = new Scanner(inputFile);
		
		String series = input.nextLine().split(",")[0];
		String[] Stringyears = input.nextLine().split(","); 
		ArrayList<Integer> years = new ArrayList<Integer>();
		for (int i = 1; i < Stringyears.length; i++) {
			years.add(Integer.parseInt(Stringyears[i]));
		}
		
		ArrayList<Country> countries = new ArrayList<Country>();
		
		while (input.hasNextLine()) {
			ArrayList<Double> values = new ArrayList<Double>();
			String line = input.nextLine();
			String[] countryname=line.split(",");
			String name = countryname[0]; 
			String[] StringVals = line.split(",");
		
		
			for (int i = 0; i < years.size(); i++) {
				values.add(Double.parseDouble(StringVals[i+1])); 
			}
			//((double) Math.round(Double.parseDouble(StringVals[i+1])));
			countries.add(new Country(name, series, years, values)); 
		}
		
		for (Country country : countries) {
			System.out.println(country.getAcronym() +" for " + years.get(0) + "-" + years.get(years.size() - 1));
			System.out.println();	
			System.out.println(country);
			System.out.println();
		}
		
		
		input.close();
	}
	//removes a country from the country array list based on the given name
	public static void removeByName(ArrayList<Country> countries, String Name) {
		for(int i = countries.size() - 1; i >= 0; i--)
			if(countries.get(i).getCountry().equals(Name)) {
				countries.remove(i);
			}
	}
	//removes a country from the country array list if it has no trend
	public static void removeNoTrend(ArrayList<Country> countries) {
		for(int i = countries.size() - 1; i >= 0; i--) {
			if(countries.get(i).getTrend().equals("no trend")) {
				countries.remove(i);
			}
		}
	}
	//creates a new array list containing countries that share the same data trend
	public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, String trendType) {
		ArrayList<String> trend = new ArrayList<String>();
		if(trendType.equals("up")) {	
			for(int i = 0; i < countries.size(); i++) {
				if(countries.get(i).getTrend().equals("up")) {
					trend.add(countries.get(i).getCountry());
				}
					
			}
			return trend;
		}
		else if(trendType.equals("down")) {
			for(int i = 0; i < countries.size(); i++) {
				if(countries.get(i).getTrend().equals("down")) {
					trend.add(countries.get(i).getCountry());
				}
			}
			return trend;
		}	
		else if(trendType.equals("no trend")) {
			for(int i = 0; i < countries.size(); i++) {
				if(countries.get(i).getTrend().equals("no trend")) {
					trend.add(countries.get(i).getCountry());
				}
			}
			return trend;
		}
		else {
			throw new RuntimeException("not a valid trend");
		}
	}
}