//import static org.junit.Assert.*;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.ArrayList;
import java.util.Arrays;
//import java.util.Scanner;
public class TestsHobbit
{
// @BeforeClass
// public static void setUpBeforeClass() throws Exception
// {
// }
	@Test
	public void testHobbitName() {
			Hobbit h = new Hobbit("Sam Gamgee");
				String expected = "Sam Gamgee";
				String actual = h.getName();
//assertEquals(expected, actual, "Number prints as " + actual + " instead of " + expected);
				assertEquals(expected, actual);
	}
	@Test
	public void testWizardName() {
		Wizard w = new Wizard("Dumbledore", "Dark Blue");
		String expected = "Dumbledore the Dark Blue";
		String actual = w.getName();
		//assertEquals(expected, actual, "Number prints as " + actual + " instead of " + expected);
		assertEquals(expected, actual);
	}
	@Test
	public void testWizardTravel() {
		Wizard w = new Wizard("Snape", "Scarlet");
		w.travel(9);
		int expected = 27;
		int actual = w.getDistanceTraveled();
		//assertEquals(expected, actual, "Number prints as " + actual + " instead of " + expected);
		assertEquals(expected, actual);
	}
	@Test
	public void testTravelerConstructor() {
		Traveler t = new Traveler("Ms. Shiu");
		String expected = "Ms. Shiu";
		String actual = t.getName();
		assertEquals(expected, actual);
	//assertEquals(expected, actual, "Number prints as " + actual + " instead of " + expected);
	}
	@Test
	public void testAllTravel() {
//Traveler[] travs = {new Traveler("Ms. Shiu"),new Hobbit("Sam Gamgee"),
		new Wizard("Dumbledore", "Dark Blue");
		ArrayList<Traveler> travList = new ArrayList();
		travList.add(new Traveler("Ms. Shiu"));
		travList.add(new Hobbit("Sam Gamgee"));
		travList.add(new Wizard("Dumbledore", "Dark Blue"));
		String expected = "Ms. Shiu has traveled 2 miles\nSam Gamgee has traveled 2 miles\nDumbledore the Dark Blue has traveled 6 miles\n";
		String actual = ThereAndBackAgain.allTravel(travList, 2);
		assertEquals(expected, actual);
//assertEquals(expected, actual, "Number prints as " + actual + " instead of " + expected);
	}
}
