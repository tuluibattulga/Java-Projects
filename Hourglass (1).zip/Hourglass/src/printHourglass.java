import java.util.*;

public class printHourglass {
	public static void printBase(int width) {
		System.out.print("|");
		for(int i = 1; i <= width; i++) {
			System.out.print("\"");
		}
		System.out.println("|");
	}
	public static void printCone(int width) {
		int rows = 0;
		if(width % 2 == 1) {
			rows = ((width + 1) / 2);
		}
		else {
			rows = (width / 2);
		}
		for(int i = 1; i <= rows; i++) {
			for(int spaces = 1; spaces <= i; spaces++) {
				System.out.print(" ");
			}
			if(i == rows) {
				for(int lines = 1; lines <= (int)(width / rows); lines++) {
					System.out.print("|");
				}
				System.out.println();
			}
			else {
				System.out.print("\\");
				for(int fill = 1; fill <= width - (2 * i); fill++) {
					System.out.print(":");
				}
				System.out.println("/");
			}
		}
	}
	public static void printDownCone(int width) {
		int rows = 0;
		if(width % 2 == 1) {
			rows = ((width + 1) / 2) - 1;
		}
		else {
			rows = (width / 2) - 1;
		}
		for(int i = rows; i >= 1; i--) {
			for(int spaces = i; spaces >= 1; spaces--) {
				System.out.print(" ");
			}			
			System.out.print("/");
			for(int fill = 1; fill <= width - (2 * i); fill++) {
					System.out.print(":");
			}
			System.out.println("\\");
		}
	}
	public static void main(String[] args) {
		Scanner userInput  = new Scanner(System.in);
		System.out.println("Welcome!");
		System.out.println("What do you want the width to be?");
		int input = userInput.nextInt();
		printBase(input);
		printCone(input);
		printDownCone(input);
		printBase(input);
		userInput.close();
	}
}

