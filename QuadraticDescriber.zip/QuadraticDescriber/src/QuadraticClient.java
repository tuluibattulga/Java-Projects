/**
 * Handles the user input for the quadrDescriber method. Once the quadratic equation is entered, a description of the equation is 
 * given that provides the concavity, axis of symmetry, vertex, x-intercepts, and y-intercept
 * @author Tului Battulga
 * @version 10/7/2023
 */
import java.util.*;

public class QuadraticClient {
	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		System.out.println("Welcome to the Quadratic Describer");
		boolean repeat = true;
		while(repeat == true) {
			System.out.println("Provide values for coefficients a, b, and c");
			System.out.println("a: ");
			double a = userInput.nextDouble();
			System.out.println("b: ");
			double b = userInput.nextDouble();
			System.out.println("c: ");
			double c = userInput.nextDouble();
			System.out.println(Quadratic.quadrDescriber(a, b, c));	
			System.out.println("Do you want to keep going? (Type \"quit\" to end)");
			if(userInput.next().equals("quit")) {
				repeat = false;
			}
		}
		userInput.close();
	}	
}
