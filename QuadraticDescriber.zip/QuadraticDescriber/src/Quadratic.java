/**
 * Does all the calculations and string concatenation so that the correct description of the quadratic given in QuadraticClient.java is outputted to the user.
 * @author Tului Battulga
 * @version 10/7/2023
 */
public class Quadratic {
	//returns the square of the integer given
	public static int square(int num) {
		return num * num;
	}
	//returns the square of the double given
	public static double square(double num) {
		return num * num;
	}
	//returns the higher double of the two given
	public static double max(double num1, double num2) {
		if(num1 > num2) {
			return num1;
		}
		else {
			return num2;
		}
	}
	//returns the lower number of the two given
	public static double min(double num1, double num2) {
		if(num1 < num2) {
			return num1;
		}
		else {
			return num2;
		}
	}	
	//returns the square root of a given double
	public static double sqrt(double num) {
		if(num < 0) throw new IllegalArgumentException ("Unable to find the square root of a negative");
		double a;
		double b = num / 2;
		do {
			a = b;
			b = (num / a + a) / 2;
		}
		while(b * b - num >= 0.005);
			return round2(b);
	}
	//returns the discriminant of a quadratic equation given
	public static double discriminant(double a, double b, double c) {
		return b * b - 4 * a * c;
	}
	//returns the roots of a quadratic equation
	public static String quadForm(double a, double b, double c) {
		String result = "";
		if (discriminant(a, b, c) < 0) {
			result = "no real roots";
		}
		else if (discriminant(a, b, c) == 0) {
			double num = ((-b) / (2 * a));
			result = "" + round2(num);
		}
		else {
			double root1 = round2((-b + sqrt(discriminant(a, b, c))) / (2 * a));
			double root2 = round2((-b - sqrt(discriminant(a, b, c))) / (2 * a));
			double first = min(root1, root2);
			double last = max(root1, root2);
			result = first + " and " + last;
		}
		return result;
	}
	//rounds a decimal to the hundreth place
	public static double round2(double deci) {
		if(deci >= 0) {
			deci += 0.005;
		}
		else {
			deci -= 0.005;
		}
		deci = (int)(deci * 100);
		deci = (double)(deci / 100);
		return deci;
	}
	//does the calculations and provides the description for a quadratic equation
	public static String quadrDescriber(double a, double b, double c) {
		String description = "Description of the graph of:\n" + a + "x^2 + " + b + "x + " + c;
		String opens = "";
		if(a < 0) {
			opens = "Opens: Down\n";
		}
		else {
			opens = "Opens: Up\n";
		}
		double x = ((-1) * b) / (2 * a);
		double y = (a * square(x)) + (b * x) + c;
		String aos = "Axis of Symmetry: " + x + "\n";
		String vertex = "Vertex: (" + x + ", " + y + ")\n";
		String xInts = "x-intercepts(s): " + quadForm(a, b, c) + "\n";
		String yInt = "y-intercept: " + c + "\n";
		return description + "\n" + opens + aos + vertex + xInts + yInt;
	}
}
