package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * Spreadsheet location class definition
 */
//Update this file with your own code.

public class SpreadsheetLocation implements Location
{	private String location;
    @Override
    public int getRow() //returns row from location fed to constuctor ex: A1 returns 0 (since its an array first row is 0)
    {
    	int row = Integer.parseInt(location.substring(1)) - 1;
        return row;
    }

    @Override
    public int getCol() //returns col from location fed to constructor ex: B2 returns 1 (since its an array first col is 0)
    {
    	String temp = (location.charAt(0) + "").toUpperCase();
    	int col = (int)(temp.charAt(0)) - 65;
        return col;
    }
    
    public SpreadsheetLocation(String cellName) //creates new SpreadsheetLocatino
    {
    	location = cellName;
    }
}