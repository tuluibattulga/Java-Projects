package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * real cell class definition
 */
public class RealCell implements Cell{
	private String value;
	
	public RealCell(String val) { //constructor for real cell
		value = val;
	}
	public String abbreviatedCellText() { //returns cell value text 
		return (value + "          ").substring(0, 10);
	}
	public String fullCellText() { //returns unformatted value text
		return value;
	}
	public Double getDoubleValue() { //returns value as a double
		return Double.parseDouble(value);
	}
}
