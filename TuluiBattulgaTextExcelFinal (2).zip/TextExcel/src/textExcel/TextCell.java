package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * text cell class definition
 */
public class TextCell implements Cell{
	private String text;
	public TextCell(String t) { //creates new text cell
		text = t;
	}
	public String abbreviatedCellText() { //returns text shortened to fit 10 spaces or filled with spaces to reach 10
		String abb = "";
		String word = text.substring(1, text.length() - 1);
		if(word.length() > 10) {
			abb = word.substring(0, 10);
		}
		else {
			abb = word;
			for(int i = 0; i < 10 - word.length(); i++) {
				abb += " ";
			}
		}
		return abb;
		// text for spreadsheet cell display, must be exactly length 10
	}
	public String fullCellText() { //returns unshortetened text
		return text;
	}
}
