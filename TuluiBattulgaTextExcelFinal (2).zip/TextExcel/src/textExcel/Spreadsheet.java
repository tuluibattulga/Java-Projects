package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * spreadsheet class definition
 */
import java.util.ArrayList;

// Update this file with your own code.

public class Spreadsheet implements Grid {
	private Cell[][] sheet;
	private int rows = 20;
	private int cols = 12;
	private Boolean doHistory = false;
	private int historyLength = -1;
	private ArrayList<String> history = new ArrayList<String>();
 
	@Override
	public String processCommand(String command) //processes all commands that are input into console window and returns the modified spreadsheet
	{
		String[] line = command.split(" ", 3);
		if(doHistory = true && !line[0].equals("history") && historyLength > 0) {
			history.add(command);
			if(history.size() > historyLength) {
				history.remove(0);
			}
		}
		if(line[0].equalsIgnoreCase("history")) {
			if(line[1].equalsIgnoreCase("start")) {
				historyLength = Integer.parseInt(line[2]);
				doHistory = true;
				return "";
			}
			else if(line[1].equalsIgnoreCase("display")) {
				String output = "";
				for(int i = history.size() - 1; i >= 0; i--) {
					output += history.get(i);
					output += "\n";
				}
				return output;
			}

			else if(line[1].equalsIgnoreCase("clear")) {
				for(int i = 0; i < Integer.parseInt(line[2]); i++) {
					if(history.size() > 0) {
						history.remove(0);
					}
				}
				return "";
			}
			else if(line[1].equalsIgnoreCase("stop")) {
				doHistory = false;
				history.clear();
				return "";
			}
		}
		else if(line.length == 3) { //code for set cell 
			SpreadsheetLocation loc = new SpreadsheetLocation(line[0]);
			if(command.indexOf("\"") != -1) { //checks to see if value is a text cell
				sheet[loc.getCol()][loc.getRow()] = new TextCell(line[2]);
				return getGridText();
			}
			else if(command.indexOf("(") != -1) {//checks to see if value is a formula cell
					sheet[loc.getCol()][loc.getRow()] = new FormulaCell(line[2], this);
					return getGridText();
			}
			else if(command.indexOf("%") != -1) {//checks to see if value is a percent cell
				sheet[loc.getCol()][loc.getRow()] = new PercentCell(line[2]);
				return getGridText();
			}
			else { //checks to see if value is a value cell
				sheet[loc.getCol()][loc.getRow()] = new ValueCell(line[2]);
				return getGridText();
			}
		}
		else if(line.length == 2) {
			if(line[0].equalsIgnoreCase("clear")) { //clears specific cells in the spreadsheet
				SpreadsheetLocation loc = new SpreadsheetLocation(line[1]);
				sheet[loc.getCol()][loc.getRow()] = new EmptyCell();
				return getGridText();
			}
		}
		else if(line.length == 1) { 
			if(command.equalsIgnoreCase("clear")) { //clears whole spreadsheet
				for(int i = 0; i < cols; i++) {
					for(int j = 0; j < rows; j++) {
						sheet[i][j] = new EmptyCell();
					}
				}
				return getGridText();
			}
			else if(command.equalsIgnoreCase("quit")) { //stops code
				return "";
			}
			else if(command.length() == 2 || command.length() == 3) {
				SpreadsheetLocation loc = new SpreadsheetLocation(command); //returns value at specified cell
				return sheet[loc.getCol()][loc.getRow()].fullCellText();
			}
		}
		return "";
	}
	@Override
	public int getRows() { //returns total amount of rows in spreadsheet

		// TODO Auto-generated method stub
		return rows;
	}

	@Override
	public int getCols() //returns total columns in spreadsheet
	{
		// TODO Auto-generated method stub
		return cols;
	}

	@Override
	public Cell getCell(Location loc) //returns the cell at location
	{  
		return sheet[loc.getCol()][loc.getRow()];
	}
	
	public Cell getCell(int y, int x) { //returns cell at given row and col
		return sheet[y][x];
	}

	public Cell[][] getSheet() { //returns the spreadsheet
		return sheet;
	}
	@Override
	public String getGridText() //returns the grid text with abbreviated cell texts
	{
		String grid = "   ";
		
		for (int i = 0; i < cols; i++) {
			grid += "|";
			grid += (char)(65+i);
			grid += "         ";
		}
		
		grid += "|";
		
		for (int i = 1; i <= rows; i++) {
			grid += "\n";
			grid += (i);
			for (int j = 0; j < 3-Integer.toString(i).length(); j++) {
				grid += " ";				
			}
			for (int j = 0; j < cols; j++) {
				grid += "|";
				grid += sheet[j][i-1].abbreviatedCellText();
			}
			grid += "|";
		}
		
		grid += "\n";
		
		return grid;
	}
	
	public boolean outOfBounds(SpreadsheetLocation loc) { //returns true if location is out of bounds; false if not
		// returns if l is outside the range of the spreadsheet
		return (loc.getCol() < 0 || loc.getCol() > cols - 1 || loc.getRow() < 0 || loc.getRow() > rows);
	}
	public void addCommand(String command) {
		history.add(command);
	}
	public void removeCommand() {
		history.remove(0);
	}
	public ArrayList<String> getHistory() {
		return history;
	}
	
	public Spreadsheet() { //spreadsheet constructor - creates 2d array full of empty cells
		sheet = new Cell[cols][rows]; 
		for(int i = 0; i < cols; i++) {
			for(int j = 0; j < rows; j++) {
				sheet[i][j] = new EmptyCell();
			}
		}	
		
	}

}
