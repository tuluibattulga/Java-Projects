package textExcel;
/* Tului Battulga
 * Feb. 25, 20234
 * empty cell class definition
 */
public class EmptyCell implements Cell{ //place holder cell for cells with no value in the spreadsheet
	public String abbreviatedCellText() {  //returns 10 empty spaces to uphold spreadsheet structure
		return "          ";
	}
	public String fullCellText() { //returns empty string
		return "";
	}
}
