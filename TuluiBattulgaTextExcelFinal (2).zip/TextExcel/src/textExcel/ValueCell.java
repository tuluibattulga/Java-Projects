package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * value cell class definition
 */
public class ValueCell extends RealCell implements Cell {
	private String value;
	public ValueCell(String val) { //creates new ValeueCell
		super(val);
		value = val;	
	}
	public String abbreviatedCellText() { //returns full value shortened to fit 10 spaces or filled to reach 10 spaces
		return (getDoubleValue() + "          ").substring(0, 10);
	}
	public String fullCellText() { //returns full value as a string
		return super.fullCellText();
	}
	public Double getDoubleValue() { //returns full value as a double
		return Double.parseDouble(value);
	}
}
