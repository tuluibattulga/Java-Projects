package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * percent cell class definition
 */
public class PercentCell extends RealCell implements Cell {
	private String percent;
	
	public PercentCell(String per) { //constructor for percent cell
		super(per);
		percent = per;
	}
	public String abbreviatedCellText() { //returns percentage shortened to ones place + spaces to reach 10 spaces
		return (percent.substring(0, percent.indexOf(".")) + "%" + "          ").substring(0, 10);
	}
	public String fullCellText() { //returns full percentage as a decimal as a string
		return Double.toString(getDoubleValue());
	}
	public Double getDoubleValue() { //returns full percentage as a decimal
		return Double.parseDouble(percent.substring(0, percent.length() - 1)) / 100; 
	}
}
