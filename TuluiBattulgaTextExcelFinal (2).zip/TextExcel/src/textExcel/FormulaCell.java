package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * formula cell class definition
 */
import java.util.ArrayList;

public class FormulaCell extends RealCell {
	private String formula;
	private Spreadsheet spreadsheet;
	private Boolean isError = false;
	public FormulaCell(String form, Spreadsheet sheet) { //constructor for formula cell
		super(form);
		formula = form;
		spreadsheet = sheet;
	}
	public String abbreviatedCellText() { //returns fully calculated formula with empty spaces added to reach 10 spaces
		if(isError) {
			return "#ERROR    ";
		}
		else {
			return (Double.toString(getDoubleValue()) + "          ").substring(0, 10);
		}
	}
	public String fullCellText() { //returns full formula text ex: "( 1 + 2 / 3 )"
		return formula;
	}
	public Double getDoubleValue() { //does calculations for formulas
		ArrayList<String> arrList = new ArrayList<String>();
		String[] calc = formula.substring(2, formula.length() - 2).split(" ");
		if(calc[0].equalsIgnoreCase("SUM") || calc[0].equalsIgnoreCase("AVG")) {//checks for SUM or AVG command
			String[] coords = calc[1].split("-");
			SpreadsheetLocation coord1 = new SpreadsheetLocation(coords[0]);
			SpreadsheetLocation coord2 = new SpreadsheetLocation(coords[1]);
			Double total = 0.0;
			int celltotal = 0;
			for(int row = coord1.getRow(); row <= coord2.getRow(); row++) {
				for(int col = coord1.getCol(); col <= coord2.getCol(); col++) {
					total += ((RealCell)spreadsheet.getCell(col, row)).getDoubleValue();
					celltotal++;
				}
			}
			if(calc[0].equalsIgnoreCase("AVG")) { //if it is average it returns a different output than SUM would - divides the total by the amount of cells
				return total / celltotal; //output for AVG
			}
			return total; //output for SUM
		}
		else { //if it's not SUM or AVG it does calculation for other 
				for(int i = 0; i < calc.length; i++) {
					if(Character.isLetter(calc[i].charAt(0))) {
						SpreadsheetLocation loc = new SpreadsheetLocation(calc[i]);
						
						Double cell = ((RealCell)spreadsheet.getCell(loc.getCol(), loc.getRow())).getDoubleValue();
						arrList.add(Double.toString(cell));
					}
					else {
						arrList.add(calc[i]);	
					}
				}
			
				/*
				Double total = Double.parseDouble(arrList.get(0));
				for(int i = 1; i < arrList.size() - 1; i += 2) {
					if(arrList.get(i).equals("+")) {
						total += Double.parseDouble(arrList.get(i + 1));
					}
					if(arrList.get(i).equals("-")) {
						total -= Double.parseDouble(arrList.get(i + 1));
					}
					if(arrList.get(i).equals("*")) {
						total *= Double.parseDouble(arrList.get(i + 1));
					}
					if(arrList.get(i).equals("/")) {
						total /= Double.parseDouble(arrList.get(i + 1));
						
					}
				
				}
				*/
				for(int i = 1; i < arrList.size() - 1; i += 2) { //PEMDAS calculation
					if(arrList.get(i).equals("*")) {
						arrList.set(i, Double.toString(Double.parseDouble(arrList.get(i - 1)) * Double.parseDouble(arrList.get(i + 1))));
						arrList.remove(i + 1);
						arrList.remove(i - 1);
						i -= 2;
					}
				}
				for(int i = 1; i < arrList.size() - 1; i += 2) {
					if(arrList.get(i).equals("/")) {
						arrList.set(i, Double.toString(Double.parseDouble(arrList.get(i - 1)) / Double.parseDouble(arrList.get(i + 1))));
						arrList.remove(i + 1);
						arrList.remove(i - 1);
						i -= 2;
					}
				}
				Double total = Double.parseDouble(arrList.get(0));
				for(int i = 1; i < arrList.size() - 1; i += 2) {
					if(arrList.get(i).equals("+")) {
						total += Double.parseDouble(arrList.get(i + 1));
					}
					if(arrList.get(i).equals("-")) {
						total -= Double.parseDouble(arrList.get(i + 1));
					}
				}
				if(total.isInfinite()) { //checks to see if answer is infinite (ex: something is divided by 0);
					isError = true;
				}
				return total;
		}
		
	}
	public boolean outOfBounds(SpreadsheetLocation l) { //code to see if location is out of bounds of spreadsheet
		// returns if l is outside the range of the spreadsheet
		return (l.getCol() < 0 || l.getCol() > 12 || l.getRow() < 0 || l.getRow() > 20);
	}
	
}
