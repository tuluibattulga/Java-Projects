package textExcel;
/* Tului Battulga
 * Feb. 25, 2024
 * client code for text excel
 */
import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args) //client code
	{
		Scanner input = new Scanner(System.in);
		Spreadsheet sheet = new Spreadsheet();
		System.out.println("Welcome");
		System.out.println();		System.out.println();
		System.out.println(sheet.getGridText());
		String out = input.nextLine();
		while(!out.equals("quit")) {
			//code will go here for main program
			System.out.println(sheet.processCommand(out));
			out = input.nextLine();
		}
		input.close();
	}
}
